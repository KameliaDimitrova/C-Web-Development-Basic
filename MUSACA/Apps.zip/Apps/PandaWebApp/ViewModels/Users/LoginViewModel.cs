﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ExamWeb.ViewModels.Users
{
    public class LoginViewModel
    {
        public string Username { get; set; }

        public string Password { get; set; }
    }
}
