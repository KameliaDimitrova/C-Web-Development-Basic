﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ExamWeb.ViewModels.Home
{
 public class ProductMakeOrderViewModel
    {
        public long Barcode { get; set; }
        public int Quantity { get; set; }
    }
}
