﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ExamWeb.ViewModels.Products
{
  public  class AllProductsListViewModel
    {
        public IList<OneProductViewModel> Products { get; set; }
    }
}
