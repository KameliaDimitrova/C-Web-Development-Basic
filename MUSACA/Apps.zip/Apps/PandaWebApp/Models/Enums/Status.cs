﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ExamWeb.Models.Enums
{
    public enum Status
    {
        Active=1,
        Completed=2
    }
}
