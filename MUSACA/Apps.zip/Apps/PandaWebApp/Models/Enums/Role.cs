﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ExamWeb.Models.Enums
{
    public enum Role
    {
        Admin = 1,
        User = 2
    }
}
